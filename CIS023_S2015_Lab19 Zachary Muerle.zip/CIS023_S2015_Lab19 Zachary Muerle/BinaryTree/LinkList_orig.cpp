#include "stdafx.h"
#include "LinkList.h"
//ABSOLUTELY nothing. everything is inline in the headder file. however: I need this file here for... reasons.